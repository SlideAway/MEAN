//모듈
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router'
import { FlashMessagesModule } from 'angular2-flash-messages';
import { HttpModule } from '@angular/http';
//컴포넌트
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UserlistComponent } from './components/userlist/userlist.component';
import { UseritemComponent } from './components/useritem/useritem.component';
import { MovieComponent } from './components/movie/movie.component';
import { EncryptComponent } from './components/encrypt/encrypt.component';
import { MacComponent } from './components/mac/mac.component';
import { BlogComponent } from './components/blog/blog.component';
import { AboutComponent } from './components/about/about.component';
//서비스
import { ValidateService } from './services/validate.service';
import { AuthService } from './services/auth.service';
import { AuthGuard } from './guards/auth.guard';
import { CertComponent } from './components/cert/cert.component';
import { SearchComponent } from './components/search/search.component';




const appRoutes:Routes = [
  {path:'', component:HomeComponent},
  {path:'register', component:RegisterComponent},
  {path:'login', component:LoginComponent},
  {path:'dashboard', component:DashboardComponent, canActivate:[AuthGuard]},
  {path:'profile', component:ProfileComponent, canActivate:[AuthGuard]},
  {path:'useritem', component:UseritemComponent},
  {path:'userlist', component:UserlistComponent},
  {path:'movie', component:MovieComponent},
  {path:'about', component:AboutComponent},
  {path:'blog', component:BlogComponent, canActivate:[AuthGuard]},
  {path:'encrypt', component:EncryptComponent, canActivate:[AuthGuard]},
  {path:'mac', component:MacComponent, canActivate:[AuthGuard]},
  {path:'cert', component:CertComponent, canActivate:[AuthGuard]},
  {path:'search', component:SearchComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    DashboardComponent,
    ProfileComponent,
    UserlistComponent,
    UseritemComponent,
    MovieComponent,
    EncryptComponent,
    MacComponent,
    BlogComponent,
    AboutComponent,
    CertComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    FlashMessagesModule.forRoot(),
    HttpModule
  ],
  providers: [
    ValidateService,
    AuthService,
    AuthGuard
  ],
  bootstrap: [AppComponent]


})



export class AppModule {

}
