import { Http, Headers } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class MovieService {
  constructor(private http: Http) {}

  getMovieInfo(title) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let ep = this.prepEndpoint('movies/findmovie');
    return this.http.post(ep, title, {headers:headers})
    //return this.http.post("movies/findmovie", title, {headers:headers})
      .pipe(map(res => res.json()));
  }

  getImage(title) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let ep = this.prepEndpoint('movies/getImage');
    return this.http.post(ep, title, {headers:headers})
    //return this.http.post("movies/findmovie", title, {headers:headers})
      .pipe(map(res => res.json()));
  }

  prepEndpoint(ep) {
    return 'http://localhost:3000/' + ep;
    //return 'https://localhost:3000/' + ep;
    //return 'http://isweb.joongbu.ac.kr:21000/' + ep;
  }

}
