import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { map } from "rxjs/operators";
import { tokenNotExpired } from 'angular2-jwt';

import * as forge from 'node-forge';
var pki = forge.pki;

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  pToken: any;
  sToken: any;
  authToken: any;
  user: any;

  constructor(private http: Http) { }

  certRequest(request) {
    var keypair = pki.rsa.generateKeyPair(2048);
    var publicKey = keypair.publicKey;
    var privateKey = keypair.privateKey;
    var privateKeyPem = pki.privateKeyToPem(privateKey);
    var publicKeyPem = pki.publicKeyToPem(publicKey);
    var user1 = JSON.parse(localStorage.getItem('user')).username;
    if(request.common != user1) {

    }else {
      localStorage.setItem('privateKey', privateKeyPem);

      const req = {
        country:request.country,
        state:request.state,
        locality:request.locality,
        organization:request.organization,
        orgUnit:request.orgUnit,
        common:request.common,
        publicKey:publicKeyPem
      }
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let ep = this.prepEndpoint('users/cert');
      return this.http.post(ep, req, {headers:headers}).pipe(map(res => res.json()));
    }
  }

  storeCert(cert, caCert) {
    localStorage.setItem('cert', cert);
    localStorage.setItem('caCert', caCert);
  }

  getKey(currT, stoken) {
    var md = forge.md.sha256.create();
    md.update(currT + stoken);
    return md.digest().toHex();
  }
  encryptedMessage(encrypted, currentTime, ptoken) {
    let headers = new Headers();
    headers.append('Authorization', ptoken);
    headers.append('Ctime', currentTime);
    headers.append('Enc', encrypted);
    headers.append('Content-Type', 'application/json');

    let ep = this.prepEndpoint('users/encrypt');
    return this.http.get(ep, { headers: headers }).pipe(map(res => res.json()));
  }

  getEncrypt(plaintext, key) {
    var plaintextUtf8 = forge.util.encodeUtf8(plaintext);
    var key1 = forge.util.hexToBytes(key);
    var cipher = forge.cipher.createCihpher('AES-ECB', key1);
    cipher.start();
    cipher.update(forge.util.createBuffer(plaintextUtf8, 'binary'));
    cipher.finish();
    var ciphertext = cipher.output;
    return forge.util.bytesToHex(ciphertext);
  }

  getCurrTime() {
    return new Date().getTime();
  }

  getPubToken() {
    console.log('ptoken in auth.service = ' + localStorage.getItem('id_ptoken'));
    return localStorage.getItem('id_ptoken');
  }

  getSecToken() {
    console.log('stoken in auth.service = ' + localStorage.getItem('id_stoken'));
    return localStorage.getItem('id_stoken');
  }

  computeAuth(currT, stoken) {
    var md = forge.md.sha256.create();
    md.update(currT + stoken);
    return md.digest().toHex();
  }

  registerUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let ep = this.prepEndpoint('users/register');
    return this.http.post(ep, user, { headers: headers })
      //return this.http.post("users/register", user, { headers: headers })
      .pipe(map(res => res.json()));
  }

  authenticateUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let ep = this.prepEndpoint('users/authenticate');
    return this.http.post(ep, user, { headers: headers })
      //return this.http.post("users/authenticate", user, { headers: headers })
      .pipe(map(res => res.json()));
  }

  getProfile(ptoken, currT, auth) {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Aujthorization', ptoken);
    headers.append('Ctime', currT);
    headers.append('Auth', auth);
    headers.append('Content-Type', 'application/json');
    let ep = this.prepEndpoint('users/profile');
    return this.http.get(ep, { headers: headers })
      //return this.http.get("users/profile", { headers: headers })
      .pipe(map(res => res.json()));
  }

  storeUserData(ptoken, stoken, user) {
    localStorage.setItem('id_ptoken', ptoken);
    localStorage.setItem('id_stoken', stoken);
    localStorage.setItem('user', JSON.stringify(user));
    this.pToken = ptoken;
    this.sToken = stoken;
    this.user = user;
  }

  loadToken() {
    const ptoken = localStorage.getItem('id_ptoken');
    const stoken = localStorage.getItem('id_stoken');

    this.pToken = ptoken;
    this.sToken = stoken;
  }

  logout() {
    this.pToken = null;
    this.sToken = null;
    this.user = null;
    localStorage.clear();
  }

  loggedIn() {
    // return tokenNotExpired();
    return tokenNotExpired('id_ptoken');
  }

  prepEndpoint(ep) {
    return 'http://localhost:3000/' + ep;
    //return 'https://localhost:3000/' + ep;
    //return 'http://isweb.joongbu.ac.kr:21000/' + ep;
  }


}
