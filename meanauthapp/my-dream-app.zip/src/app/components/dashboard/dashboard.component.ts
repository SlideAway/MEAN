import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import * as forge from 'node-forge';
const pki = forge.pki;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  ptoken:string;
  stoken:string;
  certPem:string;
  caCertPem:string;
  verify:string;

  constructor(
    private authService:AuthService
  ) { }

  ngOnInit() {
    const ptoken = localStorage.getItem('id_ptoken');
    const stoken = localStorage.getItem('id_stoken');
    this.ptoken = ptoken;
    this.stoken = stoken;
    this.certPem = localStorage.getItem('cert');
    this.caCertPem = localStorage.getItem('caCert');
    var cert = pki.certificateFromPem(localStorage.getItem('cert'));
    var caCert = pki.certificateFromPem(localStorage.getItem('caCert'));
    this.verify = caCert.verify(cert);
  }

}
