import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import * as forge from 'node-forge';

@Component({
  selector: 'app-encrypt',
  templateUrl: './encrypt.component.html',
  styleUrls: ['./encrypt.component.css']
})
export class EncryptComponent implements OnInit {
  plaintext: string;
  currT: any;
  ptoken: any;
  stoken: any;
  key: any;
  encrypted: any;
  decrypted: any;

  constructor(
    private authService: AuthService,
    private flashMessage: FlashMessagesService
  ) { }
  ngOnInit() {
  }
  onEncryptSubmit() {
    this.currT = this.authService.getCurrTime();
    this.ptoken = this.authService.getPubToken();
    this.stoken = this.authService.getSecToken();
    this.key = this.authService.getKey(this.currT, this.stoken);
    this.encrypted = this.authService.getEncrypt(this.plaintext, this.key);

    this.authService.encryptedMessage(this.encrypted, this.currT, this.ptoken).subscribe(data => {
      if (data.decrypted) {
        this.decrypted = forge.util.decodeUtf8(data.decrypted.data);
      }
    });
  }
}
