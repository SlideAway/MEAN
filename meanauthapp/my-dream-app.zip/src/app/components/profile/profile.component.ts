import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  user: Object;
  ptoken: any;
  stoken: any;
  currT: any;
  auth: any;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.currT = this.authService.getCurrTime();
    this.ptoken = this.authService.getPubToken();
    this.stoken = this.authService.getSecToken();
    this.auth = this.authService.computeAuth(this.currT, this.stoken);
    this.authService.getProfile(this.ptoken, this.currT, this.auth).subscribe(profile => {
      this.user = profile.user;
    },
      err => {
        console.log(err);
        console.log(this.ptoken);
        console.log(this.stoken);
        this.authService.logout();
        this.router.navigate(['login']);
        return false;
      });
  }
}
