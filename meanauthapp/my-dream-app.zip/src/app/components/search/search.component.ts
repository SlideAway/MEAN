import { Component, OnInit } from '@angular/core';
import { MovieService } from '../../services/movie.service';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searched:boolean = false;
  movie:Object;
  inputTitle:string;
  detailInfo:Object




  constructor(
    private movieService: MovieService,
    private flashMessage: FlashMessagesService
  ) {}

  ngOnInit() {
  }
  searchMovie() {
    const title = {
      title: this.inputTitle
    }
    this.movieService.getMovieInfo(title).subscribe(data => {
      if (data.success) {
        this.movieService.getImage(title).subscribe(data => {
          if(data.success) {
            this.detailInfo = data.movie;
          }
        });
        this.searched = true;
        this.flashMessage.show("검색 완료", {cssClass:'alert-success', timeout:5000});
        this.movie = data.movie;
        }
        else {
          this.flashMessage.show("찾지 못했습니다. ", {cssClass:'alert-danger', timeout:5000});
        }
      });
    }
  }
