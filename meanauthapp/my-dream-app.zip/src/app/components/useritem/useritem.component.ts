import {
  Component,
  OnInit,
  Input //입력값 받는 라이브러리
} from '@angular/core';

@Component({
  selector: 'app-useritem',
  templateUrl: './useritem.component.html',
  styleUrls: ['./useritem.component.css']
})
export class UseritemComponent implements OnInit {
  @Input() name:string;//input으로 name에 입력을 받음
  constructor() {

  }

  ngOnInit() {
  }

}
