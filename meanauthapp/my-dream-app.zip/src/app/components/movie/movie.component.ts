import { Component, OnInit } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { map } from "rxjs/operators";
import { MovieService } from "../../services/movie.service";

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})



export class MovieComponent {
  year:Number;
  month:Number;
  date: Number;
  today: string;
  key: string = "925bf1af1aa0b15698bc7b15ad69eff6";
  kobisUrl: string = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=925bf1af1aa0b15698bc7b15ad69eff6&targetDt=";
  Movie: any;
  loading: boolean;
  kobisResult: any;
  ImgResult: any;
  array: Array<Number> = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  title: Array<string>;
  poster:Array<string> = ["", "", "", "", "", "", "", "", "", ""];



  constructor(
    private http: Http,
    private movieService: MovieService
  ) {}

  ngOnInit() {
    this.loading = true;
    this.getDate();
    let url = this.kobisUrl + this.today;
    this.http.get(url).subscribe((res: Response) => {
      this.kobisResult = res.json();

      for(let i=0; i<10; i++) {
        let title = {
          title:this.kobisResult.boxOfficeResult.dailyBoxOfficeList[i].movieNm
        }
      this.movieService.getImage(title).subscribe(data => {
        if(data.success) {
          this.ImgResult = data.movie;
          console.log(this.ImgResult.poster);
        }
        else {
          console.log('포스터 가져오기 실패');
        }
      });
      }
      this.loading = false;
    });

  }

  getDate() {
    var date = new Date();
    var today = date.getDate();
    this.date = today;
    today = today - 1;
    var month = date.getMonth();
    this.month = month;
    var year = date.getFullYear();
    this.year = year;
    month = month + 1;
    if (today < 10) {
      this.today = year.toString() + month.toString() + "0" + today.toString();
    }
    else {
      this.today = year.toString() + month.toString() + today.toString();
    }
  }

  getImage(){
    let title;
    console.log(title);
    for(let i=0; i<10; i++) {
      title = this.kobisResult.boxOfficeResult.dailyBoxOfficeList[i].movieNm;
    this.movieService.getImage(title).subscribe(data => {
      if(data.success) {
        console.log(data.detailInfo.poster);
        this.poster[i] = data.detailInfo;
      }
    });
  }
  }
}
